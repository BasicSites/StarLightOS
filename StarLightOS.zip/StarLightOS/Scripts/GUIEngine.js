let cancelLoad = false;
let activePopup = null;
window.onerror = function(message, source, lineno, colno, error) {
    BugCheck();
};
function Reboot() {
    window.location.href = "Misc/Blackscreen.html";
}

function BugCheck() {
    window.location.href = "Errors/BSoD.html";
}
function showDialog(title, message, buttonText) {
    document.getElementById('dialog-title').textContent = title;
    document.getElementById('dialog-message').textContent = message;
    document.getElementById('dialog-button').textContent = buttonText;
    document.getElementById('dialog-overlay').style.display = 'block';
    playSound('Errorsound')
}

function OpenWindow(WindowID) {
    try {
        const windowElement = document.getElementById(WindowID);
        if (windowElement) {
            windowElement.style.display = 'flex';
        }
    } catch (error) {
        BugCheck()
    }
}

function CloseWindow(WindowID) {
    const windowElement = document.getElementById(WindowID);
    if (windowElement) {
        windowElement.style.display = 'none';
    }
}
function OpenWindowStartmenu(WindowID){
    OpenWindow(WindowID)
    toggleStartMenu()
}

function toggleStartMenu() {
    const startMenu = document.getElementById('start-menu');
    if (startMenu.style.display === 'none' || startMenu.style.display === '') {
        startMenu.style.display = 'block';
    } else {
        startMenu.style.display = 'none';
    }
}

document.querySelectorAll('.window').forEach(window => {
    const header = window.querySelector('.window-header');
    let isDragging = false;
    let offsetX = 0, offsetY = 0;

    header.addEventListener('mousedown', (e) => {
        isDragging = true;
        offsetX = e.clientX - window.offsetLeft;
        offsetY = e.clientY - window.offsetTop;
        document.body.style.cursor = 'grabbing';
    });

    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            window.style.left = `${e.clientX - offsetX}px`;
            window.style.top = `${e.clientY - offsetY}px`;
        }
    });

    document.addEventListener('mouseup', () => {
        isDragging = false;
        document.body.style.cursor = 'default';
    });
});
function closeDialog() {
    document.getElementById('dialog-overlay').style.display = 'none';
}
function playSound(id) {
    const audio = document.getElementById(id);
    audio.play();
}
document.addEventListener("DOMContentLoaded", () => {
    showDialog("Beta","Dies ist eine Beta von StarLightOS","OK")
    
})
document.addEventListener("click", () => {
    playSound("StartSound")
    
},{once:true})

function Notify(title, message) {
    const container = document.getElementById('notification-container');
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `<strong>${title}</strong><p>${message}</p>`;
    
    container.appendChild(notification);

    // Remove notification after 5 seconds with fade-out animation
    setTimeout(() => {
        notification.classList.add('fade-out');
        notification.addEventListener('animationend', () => {
            container.removeChild(notification);
        });
    }, 5000);
}
document.addEventListener("contextmenu", (event) => {
    event.preventDefault(); // Standard-Browsermenü verhindern

    const menu = document.getElementById("contextmenu");

// Positioniere das Menü an der Mausposition
menu.style.top = `${event.clientY}px`;
menu.style.left = `${event.clientX}px`;
menu.style.display = "block";
});

// Klick außerhalb des Menüs, um es zu schließen
document.addEventListener("click", () => {
const menu = document.getElementById("contextmenu");
menu.style.display = "none";
});

// Optionale Funktion für Klicks auf Menüoptionen
document.getElementById("contextmenu").addEventListener("click", (e) => {
if (e = 'Terminal'){
OpenWindow('Terminal')
}
});

function Progress(Title, LoadingTime, WindowText) {
    cancelLoad = false;

    // Create popup elements
    const popup = document.createElement('div');
    popup.className = 'popup';

    const closeButton = document.createElement('button');
    closeButton.className = 'popup-close button';
    closeButton.innerText = 'X';
    closeButton.onclick = cancel;

    const title = document.createElement('div');
    title.className = 'popup-title';
    title.innerText = Title;

    const text = document.createElement('div');
    text.className = 'popup-text';
    text.innerText = WindowText;

    const progressBarContainer = document.createElement('div');
    progressBarContainer.className = 'progress-bar-container';

    const progressBar = document.createElement('div');
    progressBar.className = 'progress-bar';

    progressBarContainer.appendChild(progressBar);
    popup.appendChild(closeButton);
    popup.appendChild(title);
    popup.appendChild(text);
    popup.appendChild(progressBarContainer);
    document.body.appendChild(popup);

    activePopup = popup;

    // Make popup draggable
    let offsetX = 0, offsetY = 0;
    popup.onmousedown = function (e) {
        offsetX = e.clientX - popup.offsetLeft;
        offsetY = e.clientY - popup.offsetTop;
        document.onmousemove = function (e) {
            popup.style.left = (e.clientX - offsetX) + 'px';
            popup.style.top = (e.clientY - offsetY) + 'px';
        };
        document.onmouseup = function () {
            document.onmousemove = null;
            document.onmouseup = null;
        };
    };

    // Center popup initially
    popup.style.left = (window.innerWidth / 2 - popup.offsetWidth / 2) + 'px';
    popup.style.top = (window.innerHeight / 2 - popup.offsetHeight / 2) + 'px';

    // Animate progress bar
    let startTime = null;
    function animateProgress(timestamp) {
        if (cancelLoad) return;
        if (!startTime) startTime = timestamp;
        const elapsed = timestamp - startTime;
        const progress = Math.min((elapsed / LoadingTime) * 100, 100);
        progressBar.style.width = progress + '%';

        if (elapsed < LoadingTime) {
            requestAnimationFrame(animateProgress);
        } else {
            if (!cancelLoad) {
                document.body.removeChild(popup);
                activePopup = null;
                Notify("Loading Finished"," Loading Finished Successfully")
            }
        }
    }

    requestAnimationFrame(animateProgress);
}

function cancel() {
    if (activePopup) {
        cancelLoad = true;
        document.body.removeChild(activePopup);
        activePopup = null;
        Notify("Loading Cancelled"," Loading was cancelled by user")
    }
}
//fetch('list.txt')
  //      .then(response => response.text())
    //    .then(data => {
      //      const projects = parseProjects(data);
        //    projects.forEach(proj => {
    //            const tile = createProjectTile(proj);
      //          projektContainer.appendChild(tile);
//            });
  //      });

    // Projekte aus der TXT-Datei parsen
    function parseProjects(text) {
        const projects = [];
        const entries = text.split('#').slice(1);
        entries.forEach(entry => {
            const name = entry.match(/-name: (.*)/)[1];
            const url = entry.match(/-url: (.*)/)[1];
            const img = entry.match(/-img: (.*)/)[1];
            const desc = entry.match(/-desc: "(.*)"/)[1];
            const state = entry.match(/-state: (.*)/)[1]; // Neuen Parameter hinzufügen
            projects.push({ name, url, img, desc, state });
        });
        return projects;
    }
