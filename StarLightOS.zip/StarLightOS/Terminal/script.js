document.addEventListener('DOMContentLoaded', () => {
    const terminal = document.getElementById('terminal');
    let prompt = 'C:\\>';
    var DriveHealth = Math.floor(Math.random() * 100);
    //Warn = CHKDISK(DriveHealth)
    let inputLine = createInputLine();
    

    
    terminal.appendChild(inputLine);
    inputLine.querySelector('.input').focus();
    function CHKDISK(DriveHealth,){
            
            if (DriveHealth < 30) {
                var Warn = "true"
            } else if (DriveHealth > 30){
                var Warn = "false"
            }
            
            return Warn
    }
    function createInputLine() {
        const line = document.createElement('div');
        line.className = 'input-line';

        const promptSpan = document.createElement('span');
        promptSpan.className = 'prompt';
        promptSpan.textContent = prompt;

        const input = document.createElement('input');
        input.className = 'input';
        input.type = 'text';

        input.addEventListener('keydown', handleInput);

        line.appendChild(promptSpan);
        line.appendChild(input);

        return line;
    }

    function handleInput(event) {
        if (event.key === 'Enter') {
            const input = event.target;
            const command = input.value.trim();
            input.disabled = true;

            executeCommand(command);

            const newInputLine = createInputLine();
            terminal.appendChild(newInputLine);
            newInputLine.querySelector('.input').focus();
            terminal.scrollTop = terminal.scrollHeight;
        }
    }

    function executeCommand(command) {
        const output = document.createElement('div');
        output.className = 'output';
        Warn = CHKDISK(DriveHealth)
        if (command === 'dir') {
            console.log(Warn)
            if (Warn === "false") {
            output.innerHTML = `Drive C: Health: ${DriveHealth} %<br>Desktop - DIR<br>System - DIR`;
            } else{
                output.innerHTML = `Drive C: Health: ${DriveHealth} % DRIVE HEALTH WARNING<br>Desktop - DIR<br>System - DIR`;
            }
        } else if (command.startsWith('cd ')) {
            output.textContent = `Changing directory to ${command.slice(3)}...`;
        } else if (command.startsWith('wininit')) {
            window.location.href = "../BSoD.html"
            
        } else if (command === 'exit') {
            output.textContent = 'Exiting terminal...';
        } else if (command === ""){
            output.textContent = ``;
        } else {
            output.textContent = `Unknown command: ${command}`;
        }


        terminal.appendChild(output);
    }
});
